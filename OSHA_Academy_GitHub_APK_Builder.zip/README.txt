OSHA Academy - Android APK Builder

این بسته برای ساخت APK با GitHub Actions آماده شده است.

محتویات:
1) osha_academy_source.zip = سورس Flutter
2) .github/workflows/build-apk.yml = دستور خودکار ساخت APK

روش استفاده با گوشی:
1) در GitHub یک Repository جدید بساز.
2) فایل osha_academy_source.zip را در ریشه Repository آپلود کن.
3) فایل build-apk.yml را در مسیر دقیق .github/workflows/build-apk.yml قرار بده.
4) به تب Actions برو.
5) Workflow با نام Build OSHA Academy APK را انتخاب کن.
6) روی Run workflow بزن.
7) پس از پایان موفق، در صفحه اجرای Workflow بخش Artifacts فایل OSHA-Academy-APK را دانلود کن.
8) ZIP دانلودشده را باز کن؛ داخل آن app-release.apk قرار دارد.

نکته: Workflow خودش پوشه Android را با flutter create می‌سازد، بنابراین ناقص بودن فایل‌های Gradle داخل سورس اولیه مانع Build نمی‌شود.
